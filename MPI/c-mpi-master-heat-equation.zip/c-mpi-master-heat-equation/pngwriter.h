#ifndef PNGWRITER_H_
#define PNGWRITER_H_

int save_png(double *data, const int nx, const int ny, const char *fname,
             const char lang);

#endif
